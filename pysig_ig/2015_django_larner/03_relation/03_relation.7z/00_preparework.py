
'''
Using MySQL in Django
	http://www.cnblogs.com/fengri/articles/django5.html

Django Model Advanced
http://djangobook.py3k.cn/2.0/chapter10/

《Django web开发指南》
http://www.ziqiangxuetang.com/django/django-models.html

'''

please install below env first:
wamp server
python
django
notepad/sublime
